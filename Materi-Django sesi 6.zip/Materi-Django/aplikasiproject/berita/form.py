from django import forms
from .models import beritaModel

class beritaForm (forms.ModelForm):

    class Meta:
        model = beritaModel
        
        fields = [
            "title",
            "description",
        ]