from django.contrib import admin
from django.urls import path
from . import views
from .views import detail_view

urlpatterns = [
    path('create/', views.create_view, name='create name'),
    path('list/', views.list_view, name = 'list view'),
    path('<id>', detail_view ),
    path('<id>/update/', views.update_view, name = 'update view'),
    path('<id>/delete/', views.delete_view, name = 'delete view'),
]
