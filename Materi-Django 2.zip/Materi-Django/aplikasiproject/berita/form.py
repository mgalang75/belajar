from django import forms
from .models import beritaModel


# creating a form
class beritaForm(forms.ModelForm):

	# create meta class
	class Meta:
		# specify model to be used
		model = beritaModel

		# specify fields to be used
		fields = [
			"title",
			"description",
			"author",
		]
