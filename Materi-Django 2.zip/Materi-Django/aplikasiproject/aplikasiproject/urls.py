from urllib.parse import urlparse
from django.urls import include, path

urlpatterns = [
    # path('', include('perpustakaanapp.urls')),
    path('', include('berita.urls')),
    path('', include('buku.urls')),
]


    

