# from django.shortcuts import render
# from django.http import HttpResponse
# from re import template
from re import template
from django.http import HttpResponse
from django.template import loader

# Create your views here.
def home(request):
    template = loader.get_template ('home.html')
    return HttpResponse(template.render())

def login(request):
    template = loader.get_template ('login.html')
    return HttpResponse(template.render())

def profil(request):
    template = loader.get_template ('profil.html')
    return HttpResponse(template.render())


