# from dataclasses import fields
# from socket import fromshare
from django import forms
from .models import bukuModel

# creating a form
class bukuFrom(forms.ModelForm) :
    
    # creat meta class
    class Meta:
        # specify model to be user
        model = bukuModel
        
        # specify fileds to be user
        fields = [
            "title",
            "description",
            "date",
            "author",
            "upload",
        ]
