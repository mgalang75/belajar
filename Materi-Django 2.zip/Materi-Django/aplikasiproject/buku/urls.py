# urls.py
from django.contrib import admin 
from django.urls import path
from buku.http import MyView
from .views import bukuCreate, bukuList
from .views import bukudetailview
from .views import bukuUpdateView
from .views import bukuDeleteView


urlpatterns = [
	path('modelform/', bukuCreate.as_view()),
    path('modellist/', bukuList.as_view()),
    path('<pk>/', bukudetailview.as_view()),
    path('<pk>/modelupdate/', bukuUpdateView.as_view()),
    path('<pk>/del/', bukuDeleteView.as_view()),
]
