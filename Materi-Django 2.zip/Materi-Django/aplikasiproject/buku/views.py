from http.client import HTTPResponse
from turtle import title
from django.views.generic.edit import CreateView
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import UpdateView
from django.views.generic.edit import DeleteView
from .models import bukuModel

class bukuCreate(CreateView):

	# specify the model for create view
	model = bukuModel
	success_url = "/modellist/"

	# specify the fields to be displayed

	fields = ["title", "description", "date", "author", "upload" ]
 
class bukuList (ListView) :
    model = bukuModel
    
class bukudetailview(DetailView) :
    model = bukuModel
    
class bukuUpdateView(UpdateView):
    model = bukuModel
    
    fields = [
		"title",
		"description",
		"date",
		"author",
		"upload",
	]
    
    success_url ='/modellist/'
    
    
class bukuDeleteView(DeleteView) :
    model = bukuModel
    
    success_url = '/modellist/'
